//
//  FantasyFootball.h
//  Test Screens
//
//  Created by Jonathan Victorino on 2/22/14.
//  Copyright (c) 2014 Jonathan Victorino. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FantasyFootball : UIViewController
- (id)init;

// Store the list of players
@property (strong, nonatomic) NSMutableArray *mQuarterBackArray;
@property (strong, nonatomic) NSMutableArray *mRunningBackArray;
@property (strong, nonatomic) NSMutableArray *mWideReceiverArray;

// Store which player is selected.
@property int mQuarterBack;
@property int mRunningBack;
@property int mWideReceiver;
@end
