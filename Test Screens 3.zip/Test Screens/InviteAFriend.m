//
//  InviteAFriend.m
//  Test Screens
//
//  Created by Jonathan Victorino on 2/22/14.
//  Copyright (c) 2014 Jonathan Victorino. All rights reserved.
//

#import "InviteAFriend.h"
#import "AppDelegate.h"
#import "FantasyFootball.h"

@interface InviteAFriend ()

@end

@implementation InviteAFriend

@synthesize mQuarterBackTextField, mRunningBackTextField, mWideRecieverTextField;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

- (void)viewDidLoad

{
    
    [super viewDidLoad];
    
    AppDelegate *appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    
    int index = appDelegate.mFantasyFootball.mQuarterBack;
    
    NSString *qbString = [appDelegate.mFantasyFootball.mQuarterBackArray objectAtIndex: index];
    [mQuarterBackTextField setText: qbString];
    
    index = appDelegate.mFantasyFootball.mRunningBack;
    
    NSString *rbString = [appDelegate.mFantasyFootball.mRunningBackArray objectAtIndex: index];
    [mRunningBackTextField setText: rbString];
    
    index = appDelegate.mFantasyFootball.mWideReceiver;
    
    NSString *wrString = [appDelegate.mFantasyFootball.mWideReceiverArray objectAtIndex: index];
    [mWideRecieverTextField setText: wrString];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
