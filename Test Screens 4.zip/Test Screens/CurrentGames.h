//
//  CurrentGames.h
//  Test Screens
//
//  Created by Jonathan Victorino on 3/13/14.
//  Copyright (c) 2014 Jonathan Victorino. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CurrentGames : UITableViewController

@end
