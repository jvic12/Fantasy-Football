//
//  FantasyFootball.m
//  Test Screens
//
//  Created by Jonathan Victorino on 2/22/14.
//  Copyright (c) 2014 Jonathan Victorino. All rights reserved.
//


#import "FantasyFootball.h"

@implementation FFPlayer

@synthesize mQuarterBack,mRunningBack,mWideReceiver;

- (id)init
{
    mQuarterBack = 0;
    mRunningBack = 0;
    mWideReceiver = 0;
    return self;
}

@end

@implementation FFGame
static int s_game_count = 0;
@synthesize mFFPlayerArray,mCurrentPlayer,mGameName;
- (id)init
{
    mFFPlayerArray = [[NSMutableArray alloc] init];
    mCurrentPlayer = 0;
    mGameName = [NSString stringWithFormat:@"Game-%d", s_game_count++];
    
    // Add two players
    FFPlayer *player = [[FFPlayer alloc] init];
    [mFFPlayerArray addObject: player];
    player = [[FFPlayer alloc] init];
    [mFFPlayerArray addObject: player];
    return self;
}
- (void)setCurrentPlayer: (int) player
{
    mCurrentPlayer = player;
}

@end


@implementation FantasyFootball
// Store the list of players
@synthesize mQuarterBackArray,mRunningBackArray,mWideReceiverArray, mFFGame;

// Store which player is selected.
/*@synthesize mQuarterBack,mRunningBack,mWideReceiver, mFFGame;*/

- (id)init
{
    mQuarterBackArray = [[NSMutableArray alloc] init];
    mRunningBackArray = [[NSMutableArray alloc] init];
    mWideReceiverArray = [[NSMutableArray alloc] init];
    
    // Add some quarterbacks
    [mQuarterBackArray addObject:@"Drew Brees"];
    [mQuarterBackArray addObject:@"Peyton Manning"];
    [mQuarterBackArray addObject:@"Aaron Rodgers"];
    [mQuarterBackArray addObject:@"Tom Brady"];
    [mQuarterBackArray addObject:@"Russel Wilson"];
    [mQuarterBackArray addObject:@"Joe Flacco"];
    [mQuarterBackArray addObject:@"Cam Newton"];
    [mQuarterBackArray addObject:@"Colin Kaepernick"];
    [mQuarterBackArray addObject:@"Nick Foles"];
    [mQuarterBackArray addObject:@"Matthew Stafford"];
    [mQuarterBackArray addObject:@"Tony Romo"];
    
    [mRunningBackArray addObject:@"Adrian Peterson"];
    [mRunningBackArray addObject:@"Jamaal Charles"];
    [mRunningBackArray addObject:@"Lesean McCoy"];
    [mRunningBackArray addObject:@"Arian Foster"];
    [mRunningBackArray addObject:@"Marshawn Lynch"];
    [mRunningBackArray addObject:@"Ryan Matthews"];
    
    [mWideReceiverArray addObject:@"A.J. Green"];
    [mWideReceiverArray addObject:@"Calvin Johnson"];
    [mWideReceiverArray addObject:@"Demarius Thomas"];
    [mWideReceiverArray addObject:@"Randall Cobb"];
    [mWideReceiverArray addObject:@"Mike Wallace"];
    [mWideReceiverArray addObject:@"Dez Bryant"];
    
    mFFGame = [[FFGame alloc] init];
    
    return self;
}


@end
